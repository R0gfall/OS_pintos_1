/*
  File for 'max-threads' task implementation.
*/

#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/malloc.h"
#include "threads/thread.h"



void test_max_threads(void) 
{
  msg("Not implemented.");
}
// void test_max_mem_threads(void) 
// {
//   //msg("Not implemented.");

//   void *vrm = malloc(256);
//   int max_mem_malloc = 1;
//   while (vrm != NULL){
//     vrm = malloc(256);
//     max_mem_malloc++;
//   }
//   msg("WARNING: max_mem_malloc (x256) = %d", max_mem_malloc);  
// }



// void test_max_mem_calloc(void)
// {


//   void *vrm = calloc(128, sizeof(int));
//   int max_mem_calloc = 1;
//   while (vrm != NULL){
//     vrm = calloc(128, sizeof(int));
//     max_mem_calloc++;
//   }
//   msg("WARNING: max_mem_calloc (x128) = %d", max_mem_calloc);

// }


// void test_max_mem_palloc(void)
// {

//   void *vrm = palloc_get_page(PAL_USER);
//   int max_mem_palloc = 1;
//   while (vrm != NULL){
//     vrm = palloc_get_page(PAL_USER);
//     max_mem_palloc++;
//   }
//   msg("WARNING: max_mem_palloc (pages) = %d", max_mem_palloc);

// }

