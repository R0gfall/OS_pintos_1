/*
  File for 'ticks-stats' task implementation.
*/

#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/malloc.h"
#include "threads/thread.h"
#include "devices/timer.h"


void infinity_cycle(void){
  while(1 > 0){
  }
}

void test_ticks_stats(void) 
{


  // thread_create("new_thread_1", PRI_DEFAULT, infinity_cycle, NULL);  
  // thread_create("new_thread_2", PRI_DEFAULT, infinity_cycle, NULL);   
  // thread_create("new_thread_3", PRI_DEFAULT, infinity_cycle, NULL); 
  // thread_create("new_thread_4", PRI_DEFAULT, infinity_cycle, NULL);
  // thread_create("new_thread_5", PRI_DEFAULT, infinity_cycle, NULL);
  // thread_create("new_thread_6", PRI_DEFAULT, infinity_cycle, NULL);
  // thread_create("new_thread_7", PRI_DEFAULT, infinity_cycle, NULL);
  // thread_create("new_thread_8", PRI_DEFAULT, infinity_cycle, NULL);
  // thread_create("new_thread_9", PRI_DEFAULT, infinity_cycle, NULL);
  // thread_create("new_thread_10", PRI_DEFAULT, infinity_cycle, NULL);

  for (int i = 0; i < 10; i++){
    char name[16];
    snprintf (name, sizeof name, "thread %d", i);
    thread_create (name, PRI_DEFAULT, infinity_cycle, NULL);

  }
  
  for (int i = 0; i < 10; i++){
    timer_sleep(100);
    put_threads_from_all_list();
  }


  // // struct *new_thread_4 = thread_create(thread_4, PRI_DEFAULT, infinity_cycle, NULL); 
  // // timer_sleep(100);
  // // msg("name: thread_4, time: %d", thread_4->time_running);
  // // struct *new_thread_5 = thread_create(thread_4, PRI_DEFAULT, infinity_cycle, NULL); 
  // // timer_sleep(100);
  // // msg("name: thread_4, time: %d", thread_4->time_running);
  // // struct *new_thread_1 = thread_create(thread_6, PRI_DEFAULT, infinity_cycle, NULL); 
  // // timer_sleep(100);
  // // msg("name: thread_1, time: %d", thread_1->time_running);
  // // struct *new_thread_1 = thread_create(thread_7, PRI_DEFAULT, infinity_cycle, NULL);
  // // timer_sleep(100);
  // // msg("name: thread_1, time: %d", thread_1->time_running); 
  // // struct *new_thread_1 = thread_create(thread_8, PRI_DEFAULT, infinity_cycle, NULL); 
  // // timer_sleep(100);
  // // msg("name: thread_1, time: %d", thread_1->time_running);
  // // struct *new_thread_1 = thread_create(thread_9, PRI_DEFAULT, infinity_cycle, NULL); 
  // // timer_sleep(100);
  // // msg("name: thread_1, time: %d", thread_1->time_running);
  // // struct *new_thread_1 = thread_create(thread_10, PRI_DEFAULT, infinity_cycle, NULL); 
  // // timer_sleep(100);
  // // msg("name: thread_1, time: %d", thread_1->time_running);


  
}
